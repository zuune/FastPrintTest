<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [App\Http\Controllers\ProdukController::class, 'index']);
Route::get('/fetch-data', [App\Http\Controllers\ProdukController::class, 'fetchDataFromAPI'])->name(' .fetchDataFromAPI');
Route::resource('produk', App\Http\Controllers\ProdukController::class);
