<!-- resources/views/produk/edit.blade.php -->



<?php $__env->startSection('content'); ?>
    <h1>Edit Produk</h1>

    <form action="<?php echo e(route('produk.update', $produk->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="nama_produk">Nama Produk</label>
            <input type="text" class="form-control" id="nama_produk" name="nama_produk" value="<?php echo e($produk->nama_produk); ?>" required>
        </div>
        <div class="form-group">
            <label for="harga">Harga</label>
            <input type="number" class="form-control" id="myNumberInput"  id="harga" name="harga" value="<?php echo e($produk->harga); ?>" required>
        </div>
        <div class="form-group">
            <label for="kategori">Kategori</label>
            <input type="text" class="form-control" id="kategori" name="kategori" value="<?php echo e($produk->kategori); ?>">
        </div>
        <div class="form-group">
            <label for="status">Status</label>
            <input type="text" class="form-control" id="status" name="status" value="<?php echo e($produk->status); ?>">
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\API-FastPrintTest\resources\views/produk/edit.blade.php ENDPATH**/ ?>