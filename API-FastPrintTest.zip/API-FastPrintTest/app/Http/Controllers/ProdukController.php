<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Models\Produk;

class ProdukController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function fetchDataFromAPI()
    {
        $response = Http::get('https://recruitment.fastprint.co.id/tes/api_tes_programmer');
    
        if ($response->successful()) {
            $data = $response->json();
    
            foreach ($data as $item) {
                Produk::create([
                    'nama_produk' => $item['nama_produk'],
                    'harga' => $item['harga'],
                    'kategori' => $item['kategori'],
                    'status' => $item['status'],
                ]);
            }
    
            return response()->json(['message' => 'Data berhasil disimpan.']);
        }
    
        return response()->json(['message' => 'Gagal mengambil data dari API.']);
    }
    
    public function index()
    {
        $produk = Produk::where('status', 'bisa dijual')->get();
    
        return view('produk.index', compact('produk'));
    }
    
    public function create()
    {
        return view('produk.create');
    }
    
    public function store(Request $request)
    {
    $request->validate([
            'nama_produk' => 'required',
            'harga' => 'required|numeric',
        ]);
    
        Produk::create($request->all());
    
        return redirect()->route('produk.index')->with('success', 'Produk berhasil ditambahkan.');
    }
    
    public function edit(Produk $produk)
    {
        return view('produk.edit', compact('produk'));
    }
    
    public function update(Request $request, Produk $produk)
    {
        $request->validate([
            'nama_produk' => 'required',
            'harga' => 'required|numeric',
        ]);
    
        $produk->update($request->all());
    
        return redirect()->route('produk.index')->with('success', 'Produk berhasil diperbarui.');
    }
    
    public function destroy(Produk $produk)
    {
        $produk->delete();
    
        return redirect()->route('produk.index')->with('success', 'Produk berhasil dihapus.');
    }
}
